"""agro_assist URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from agro.views import *
from django.conf import settings
from django.conf.urls.static import static
from agro.views import home1, delete1


urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/reg/', reg, name='register'),  # Fixed the name='register'
    path('home/reg/login/', user_login, name='login'),  # Updated login function
    path('reg/login/', user_login),
    path('login/', user_login),
    path('home/reg/login/reg/', reg),
    path('reg/', reg),
    path('home/', home),
    path('home1/', home1),
    path('home1/home1/', home1),
    path('contactus/', contactus),
    path('home/contactus/', contactus),
    path('aboutus/', aboutus),
    path('home1/add_item', home1),
    path('imageUpload', home1),
    path('fileUpload/', home1),
    # path('cart/', cart),
    path('logout', home),
    path('home2/', home2),
    path('cart/<str:name>/<int:price>', cart),
    path('delete/<str:name>', delete),
    path('home1/', home1, name='home1'),
    path('delete1/<str:name>/', delete1, name='delete1'),
    path('logout', home2),
    path('info/', info),
    path('order/', order),
    # path('cart/', cart),
    path('home1', home1),
    path('farmerpage/', farmerpage),
    path('delete1/', delete1),
    path('seller/', seller),
    path('reg/login/reg/', reg),
    path('search/', search, name='search'),
    path('admin_dashboard/', admin_dashboard, name='admin_dashboard'),
    path('order-history/', order_history, name='order_history'),
    path('upload-location/', upload_location, name='upload_location'),
     path('user-orders/', user_order, name='user_order'),
     path('add_item', add_item),
    path('verify-otp/', verify_otp, name='verify_otp'),
    path('reg/', reg, name='reg'),
    path('verify-otp/reg/',reg),
    path('home/reg/home/',home),
    path('home/reg/home/reg/',reg),
    path('verify-otp/', verify_otp, name='verify_otp'),
    path("payment/", payment_page, name="payment"),
    path("create_order/", create_order, name="create_order"),
    path("verify_payment/", verify_payment, name="verify_payment"),
     path("get_cart_total/", get_cart_total, name="get_cart_total"),
     path('forgot-password/', forgot_password, name='forgot_password'),
    path('verify-reset-otp/', verify_reset_otp, name='verify_reset_otp'),
    path('reset-password/', reset_password, name='reset_password'),
     path('info/', info, name='info'),

     path('tables/', display_tables, name='display_tables'),
     path('admins/',admins),
     path("admin-login/", admin_login, name="admin_login"),
     path('view-requests/', view_requests, name='view_requests'),

    
]



urlpatterns +=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
