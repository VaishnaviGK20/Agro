from django.db import models

# Create your models here.
class usercred(models.Model):
    username=models.CharField(max_length=40,primary_key=True)
    password=models.CharField(max_length=20)

class userDetails(models.Model):
    username=models.CharField(max_length=100,primary_key=True)
    password=models.CharField(max_length=10)
    Cpassword=models.CharField(max_length=10)
    phoneNumber=models.CharField(max_length=12)
    gender=models.CharField(max_length=20)
    category=models.CharField(max_length=20)

from django.db import models

from django.db import models

class item(models.Model):
    seller = models.ForeignKey(
        userDetails, 
        on_delete=models.SET_NULL,  # If seller is deleted, set the field to NULL
        null=True,  # Allow NULL values
        blank=True  # Allow empty values in forms
    )
    iname = models.CharField(max_length=20, null=True, blank=True)
    imagepath = models.ImageField(null=True, blank=True, upload_to='images/')  # Ensure correct path
    name = models.CharField(max_length=40, primary_key=True)
    quantity = models.CharField(max_length=40)
    price = models.CharField(max_length=10)

    def __str__(self):
        return self.name



class addcart(models.Model):
    prid = models.IntegerField(primary_key=True)  # Explicit primary key
    custid = models.CharField(max_length=25)
    name = models.CharField(max_length=30)
    price = models.IntegerField()




class userreq(models.Model):
    yourname=models.CharField(max_length=20,primary_key=True)
    email=models.CharField(max_length=30)
    tel=models.CharField(max_length=12)
    message=models.CharField(max_length=60)



from django.db import models

class userinfo(models.Model):
    yourname = models.CharField(max_length=20, primary_key=True)
    phoneNumber = models.CharField(max_length=12)
    house_number = models.CharField(max_length=10, blank=True, null=True)
    cross_and_main = models.CharField(max_length=100, blank=True, null=True)
    area = models.CharField(max_length=100, blank=True, null=True)
    district = models.CharField(max_length=50, blank=True, null=True)
    pincode = models.CharField(max_length=6, blank=True, null=True)
    product_name = models.TextField(blank=True, null=True)  # Store products
    total_price = models.CharField(max_length=10, blank=True, null=True)  # Store total price

    def __str__(self):
        return self.yourname





class OrderHistory(models.Model):
    customer = models.ForeignKey(userDetails, on_delete=models.CASCADE)  # Customer Email
    product = models.ForeignKey(item, on_delete=models.CASCADE)  # Product Ordered
    total_price = models.FloatField()
    location = models.ForeignKey(userinfo, on_delete=models.SET_NULL, null=True, blank=True)  # Customer Location


from django.db import models

class Location(models.Model):
    house_number = models.PositiveIntegerField(default=1)
    cross_and_main = models.CharField(max_length=255, default="Unknown")
    area = models.CharField(max_length=255, default="Unknown")
    district = models.CharField(max_length=255, default="Unknown")
    pincode = models.CharField(max_length=6)
    user = models.ForeignKey('userDetails', on_delete=models.CASCADE, null=True)


    def __str__(self):
        return f'{self.house_number} - {self.pincode}'
    

from django.db import models

class Payment(models.Model):
    order_id = models.CharField(max_length=100, unique=True)
    payment_id = models.CharField(max_length=100, blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=10, default="INR")
    status = models.CharField(max_length=50, default="created")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.order_id

    











