from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from agro.models import *
import random

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .models import userDetails

from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login
from .models import userDetails  # Ensure your user model is imported

def user_login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        category = request.POST.get('category')

        print("Login Attempt:", username, password, category)

        # Check if user exists
        try:
            temp = userDetails.objects.get(username=username)
        except userDetails.DoesNotExist:
            return render(request, "login.html", {'msg': 'User not registered!'})

        # Validate Password
        if temp.password == password:
            if temp.category == category:
                print("Successful Login:", temp.category)
                request.session['username'] = username  # Store session

                if temp.category == "Seller":
                    return redirect('/farmerpage')  # Redirect to seller page
                elif temp.category == "Customer":
                    return redirect('/seller')  # Redirect to customer page
            else:
                return render(request, "login.html", {'msg': 'Category mismatch! Please select the correct category.'})
        else:
            return render(request, "login.html", {'msg': 'Wrong Password!'})

    return render(request, "login.html")  # Render login page on GET request



       
def home(req):
    return render(req,"home.html")


def farmerpage(req):
    return render(req,"farmerpage.html")


def seller(req):
    return render(req,"seller.html")

def admins(req):
    return render(req,"admin.html")

from django.shortcuts import render, redirect

ADMIN_USERNAME = "admin@gmail.com"
ADMIN_PASSWORD = "admin123"

def admin_login(request):
    msg = ""

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect("/admins/")  # ✅ Redirect to your existing admin page
        else:
            msg = "Invalid Username or Password!"  # ✅ Show error message

    return render(request, "admin_login.html", {"msg": msg})





def home1(req):
    if 'username' not in req.session:  # Ensure user is logged in
        return redirect('/login')

    current_user = userDetails.objects.get(username=req.session['username'])  # Get logged-in user

    if current_user.category != "Seller":  # Ensure only sellers can access
        return redirect('/seller')  # Redirect customers to their page

    if req.method == 'POST':
        quantity = req.POST.get('quantity')
        name = req.POST.get('name')
        price = req.POST.get('price')
        image = req.FILES['image']

        # Save item with the logged-in seller
        item.objects.create(seller=current_user, name=name, quantity=quantity, price=price, imagepath=image)

    # Show only the products uploaded by the logged-in seller
    values = item.objects.filter(seller=current_user)

    return render(req, 'home1.html', {'msg': " ", 'values': values})
    

def contactus(req):
    if(req.POST.get('yourname')):
        yourname = req.POST.get('yourname')
        email=req.POST.get('email')
        tel= req.POST.get('tel')
        message = req.POST.get('message')
        userreq.objects.values_list(flat=True)
        userreq(yourname=yourname,email=email,tel=tel,message=message).save()
        return render(req,"contactus.html",{'msg':'your request is recorded'})
        return HttpResponse()
    return render(req,'contactus.html')


from django.shortcuts import render
from .models import userreq  # Import the userreq model

def view_requests(request):
    requests = userreq.objects.all()  # Fetch all user queries
    return render(request, "user_requests.html", {"requests": requests})  # Pass data to template


def aboutus(req):
     return render(req,'aboutus.html')


from django.core.files.storage import FileSystemStorage
from django.shortcuts import render
from .models import item  # Ensure item model is imported
from django.shortcuts import render, redirect
from .models import item  # ✅ Make sure you're using 'Item' (uppercase)

from django.shortcuts import render, redirect
from .models import item  # Ensure correct import
from django.shortcuts import render
from .models import item  # ✅ Ensure correct import
from django.shortcuts import render
from .models import item

def add_item(request):
    if 'username' not in request.session:  # Ensure user is logged in
        return redirect('/login')

    current_user = userDetails.objects.get(username=request.session['username'])  # Get logged-in user

    if request.method == 'POST' and request.FILES.get('image'):  # Ensure file is uploaded
        prImage = request.FILES['image']
        prName = request.POST.get('name')
        prQuant = request.POST.get('quantity')
        prPrice = request.POST.get('price')

        # Save the item and associate it with the logged-in seller
        new_item = item(seller=current_user, name=prName, quantity=prQuant, price=prPrice, imagepath=prImage)
        new_item.save()

        # Fetch only the logged-in seller's products
        values = item.objects.filter(seller=current_user)

        return render(request, 'upload_location.html', {'values': values, 'msg': "Item added successfully!"})

    # Show only the seller's products
    values = item.objects.filter(seller=current_user)

    return render(request, 'home1.html', {'values': values})



from django.shortcuts import render, redirect
from .models import addcart, userDetails
import random

import random
from django.shortcuts import render
from .models import userDetails, addcart
def cart(request, name, price):
    username = request.session.get('username')

    try:
        user = userDetails.objects.get(username=username)
    except userDetails.DoesNotExist:
        return render(request, "login.html", {'msg': 'User not registered!'})

    if user.category == "Customer":
        if name != "dummy" or price != 10:
            r = random.randint(0, 1000)
            addcart.objects.create(prid=r, custid=username, name=name, price=price)

        cart_items = addcart.objects.filter(custid=username)
        
        # Store product names and amounts
        products = [item.name for item in cart_items]  
        amounts = [item.price for item in cart_items]
        total_price = sum(amounts)

        # Debug: Check product names before storing in session
        print("Product Names in Cart:", products)

        # Store in session
        request.session['product_names'] = products  
        request.session['total_price'] = total_price  
        request.session.modified = True  # Ensure session is updated

        if total_price <= 0:
            return render(request, "cart.html", {
                'msg': 'No items selected!', 
                'Product': zip(products, amounts), 
                'ProductNames': products,  # Pass product names separately
                'sum': total_price, 
                'disable_button': True
            })

        return render(request, "cart.html", {
            'Product': zip(products, amounts), 
            'ProductNames': products,  # Pass product names separately
            'sum': total_price, 
            'disable_button': False
        })
    
    else:
        return render(request, "login.html", {'msg': 'Access restricted. Only customers can add items to the cart.'})


def logout(req):
    if(req.session['username']):
        del req.session['username']
        return render(req,"login.html")
    else:
        return render(req,"login.html")

def home2(req):
    return render(req, 'home2.html', {'products': item.objects.values()})



def delete(request, name):
    username = request.session.get('username')

    # Fetch the first matching entry and delete only one instance
    item_to_delete = addcart.objects.filter(name=name, custid=username).first()
    if item_to_delete:
        item_to_delete.delete()  # Delete only the first occurrence

    # Fetch remaining items in the cart
    cart_items = addcart.objects.filter(custid=username)

    # Update session with the new cart items
    product_list = [item.name for item in cart_items]
    amount_list = [item.price for item in cart_items]

    total_price = sum(amount_list) if amount_list else 0

    request.session['product_names'] = product_list
    request.session['total_price'] = total_price
    request.session.modified = True  # Ensure session updates

    # Debugging: Check if session is updated
    print("Updated session products:", request.session.get('product_names'))
    print("Updated session total:", request.session.get('total_price'))

    return render(request, "cart.html", {
        'Product': zip(product_list, amount_list),
        'ProductNames': product_list,
        'sum': total_price,
        'disable_button': total_price == 0  # Disable order button if cart is empty
    })






from django.shortcuts import render, redirect
from .models import item
def delete1(req, name):
    if 'username' not in req.session:  # Ensure user is logged in
        return redirect('/login')

    current_user = userDetails.objects.get(username=req.session['username'])  # Get logged-in user

    try:
        # Ensure the item belongs to the logged-in seller before deleting
        obj = item.objects.get(name=name, seller=current_user)
        obj.delete()
        print(f"Deleted item: {name} uploaded by {current_user.username}")
    except item.DoesNotExist:
        print(f"Item '{name}' not found or does not belong to {current_user.username}")

    # Redirect to home1 after deletion
    return redirect('home1')





def logout(req):
    if(req.session['username']):
        del req.session['username']
        return render(req,"cart.html")
    else:
        return render(req,"cart.html")




from django.core.mail import send_mail
from django.conf import settings
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect
from django.core.exceptions import ObjectDoesNotExist
from .models import userDetails, userinfo

def info(request):
    if 'username' not in request.session:
        return redirect('/home/reg/login/')  # Redirect if user is not logged in

    username = request.session['username']

    try:
        user_detail = userDetails.objects.get(username=username)
        user_info, created = userinfo.objects.get_or_create(
            yourname=username,  
            defaults={'phoneNumber': user_detail.phoneNumber}
        )

    except ObjectDoesNotExist:
        return redirect('/home/reg/login/')  # Redirect to login if user not found

    # ✅ Extract Product Names & Total Price from Request
    products = request.GET.get('products', '')  
    total_price = request.GET.get('total', '0')  

    # ✅ Convert Product Names to a Proper List
    product_list = [p.strip() for p in products.strip("[]'").split(',') if p.strip()] if products else []

    if request.method == "POST":
        user_info.yourname = request.POST.get('yourname', user_info.yourname)
        user_info.phoneNumber = request.POST.get('phoneNumber', user_info.phoneNumber)
        user_info.house_number = request.POST.get('house_number', user_info.house_number)
        user_info.cross_and_main = request.POST.get('cross_and_main', user_info.cross_and_main)
        user_info.area = request.POST.get('area', user_info.area)
        user_info.district = request.POST.get('district', user_info.district)
        user_info.pincode = request.POST.get('pincode', user_info.pincode)
        user_info.payment_method = request.POST.get('payment_method', '')  

        # ✅ Store Product Names & Total Price in `userinfo`
        user_info.product_name = ", ".join(product_list)  
        user_info.total_price = total_price  
        user_info.save()

        # ✅ **Send Order Confirmation Email**
        subject = "Order Confirmation - Agro"
        message = f"""
        Hello {user_info.yourname},

        Your order has been placed successfully. Below are the details:

        📦 Products Ordered: {user_info.product_name}
        💰 Total Price: ₹{user_info.total_price}

        📍 Delivery Address:
        {user_info.house_number}, {user_info.cross_and_main}, {user_info.area},
        {user_info.district} - {user_info.pincode}
        📞 Contact: {user_info.phoneNumber}

        🛒 Payment Method: {user_info.payment_method.upper()}

        Thank you for shopping with us!

        Regards,
        Agro Team
        """

        recipient_email = user_info.yourname  # ✅ Use `yourname` from `userinfo` as email

        send_mail(
            subject,
            message,
            settings.EMAIL_HOST_USER,  # Sender email
            [recipient_email],  # Receiver email
            fail_silently=False,
        )

        # ✅ Redirect based on Payment Method
        return redirect('/order/' if user_info.payment_method == "cod" else '/payment/')

    return render(request, 'info.html', {
        'user_info': user_info,
        'cart_products': product_list,  
        'total_price': total_price  
    })


def save_user_info(request):
    if request.method == "POST":
        required_fields = ["yourname", "phoneNumber", "house_number", "cross_and_main", "area", "district", "pincode", "payment_method"]
        data = {field: request.POST.get(field) for field in required_fields}

        if not all(data.values()):  # Check if any field is missing
            return JsonResponse({"status": "error", "message": "All fields are required"}, status=400)

        try:
            user_info = userinfo.objects.create(**data)  # ✅ Save to database
            
            # ✅ **Send Order Confirmation Email**
            subject = "Order Confirmation - Agro"
            message = f"""
            Hello {data['yourname']},

            Your order has been placed successfully. Below are the details:

            📦 Products Ordered: {data.get('product_name', 'N/A')}
            💰 Total Price: ₹{data.get('total_price', 'N/A')}

            📍 Delivery Address:
            {data['house_number']}, {data['cross_and_main']}, {data['area']},
            {data['district']} - {data['pincode']}
            📞 **Contact:** {data['phoneNumber']}

            🛒 Payment Method: {data['payment_method'].upper()}

            Thank you for shopping with us!

            Regards,
            Agro Team
            """

            recipient_email = data['yourname']  # ✅ Use `yourname` as email

            send_mail(
                subject,
                message,
                settings.EMAIL_HOST_USER,  # Sender email
                [recipient_email],  # Receiver email
                fail_silently=False,
            )

            return JsonResponse({"status": "success", "redirect": "/order/" if data["payment_method"] == "cod" else "/payment/"})
        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return HttpResponse("Invalid request", status=400)


def order(req):
    return render(req,'order.html')



def search(request):
    products = item.objects.all()  # Default to all products
    query = ""
    if request.method == "POST":
        query = request.POST.get('searched', '')  # Get the input from the form
        if query:
            products = item.objects.filter(name__icontains=query)  # Filter items

    return render(request, 'search.html', {'products': products, 'search': query})




def admin_dashboard(request):
    # Fetch all farmers and customers based on category
    farmers = userDetails.objects.filter(category="Seller")  
    customers = userDetails.objects.filter(category="Customer")

    return render(request, "admin_dashboard.html", {"farmers": farmers, "customers": customers})



def place_order(request):
    customer_id = request.session.get('username')  # Ensure session is storing username
    cart_items = addcart.objects.filter(custid=customer_id)

    if cart_items.exists():
        for cart in cart_items:
            try:
                # Get the product by its name (assuming the name is unique)
                product = item.objects.get(name=cart.name)

                # Since we don't have a seller field, we'll assume some way to get farmer information
                farmer = "Unknown Farmer"  # You can replace this with an actual method to fetch the farmer.

                OrderHistory.objects.create(
                    customer=customer_id,
                    product=cart.name,
                    quantity=cart.quantity,  # Assuming this is the quantity being ordered
                    total_price=cart.price
                )
            except Exception as e:
                print("Error:", e)

        # Clear cart after placing the order
        cart_items.delete()
        return render('/order-history/')  # Redirect to the order history page

    return render(request, 'cart.html', {'msg': 'Cart is empty!'})


def order_history(request):
    username = request.session.get('username')  # Get the logged-in user's username

    if username:
        try:
            customer_info = userinfo.objects.get(yourname=username)
            location = f"{customer_info.house_number}, {customer_info.cross_and_main}, {customer_info.area}, {customer_info.district}, {customer_info.pincode}"
            customer_email = customer_info.yourname  # Assuming username is the email

            # Fetch product name and total price from userinfo table
            product_name = customer_info.product_name
            total_price = customer_info.total_price

            # Store order data
            order_data = {
                'product_name': product_name,  
                'price': total_price,        
                'customer_email': customer_email,  
                'location': location,  
            }

            return render(request, 'order_history.html', {'orders': [order_data]})
        
        except userinfo.DoesNotExist:
            return render(request, 'order_history.html', {'msg': 'No orders placed'})
    
    return HttpResponse("User is not logged in.")


    
from django.shortcuts import render
from .models import Location

from django.shortcuts import render
from .models import Location, userDetails
from django.http import HttpResponse

from django.shortcuts import render
from .models import Location, userDetails
from django.http import HttpResponse
def upload_location(request):
    username = request.session.get('username')  # Get the logged-in user's username from the session
    
    if not username:  # Ensure the user is logged in
        return HttpResponse("User is not logged in.")

    if request.method == 'POST':
        # Collect data from the form
        house_number = request.POST.get('house_number', '').strip()
        cross_and_main = request.POST.get('cross_and_main', '').strip()
        area = request.POST.get('area', '').strip()
        district = request.POST.get('district', '').strip()
        pincode = request.POST.get('pincode', '').strip()

        if not house_number or not cross_and_main or not area or not district or not pincode:
            return render(request, 'upload_location.html', {'error': 'All fields are required.'})

        try:
            user = userDetails.objects.get(username=username)
        except userDetails.DoesNotExist:
            return render(request, 'upload_location.html', {'error': 'User not found. Please log in again.'})

        # ✅ Delete previous location (if any) before saving the new one
        Location.objects.filter(user=user).delete()

        # ✅ Save the new location for the seller
        new_location = Location(
            house_number=house_number,
            cross_and_main=cross_and_main,
            area=area,
            district=district,
            pincode=pincode,
            user=user
        )
        new_location.save()

        # ✅ Redirect to add_item page after saving location
        return redirect('/add_item')

    return render(request, 'upload_location.html')




def user_order(request):
    username = request.session.get('username')  # Fetch the logged-in user's username from the session

    if username:  # Check if the user is logged in
        # Fetch the orders for the logged-in customer from the OrderHistory model
        orders = OrderHistory.objects.filter(customer=username)

        if orders.exists():
            user_order_data = []
            for order in orders:
                # Prepare the order data for displaying
                order_data = {
                    'product_name': order.product,
                    'quantity': order.quantity,
                    'total_price': order.total_price,
                    'order_date': order.order_date,
                }
                user_order_data.append(order_data)

            return render(request, 'user_order.html', {'orders': user_order_data})
        else:
            return render(request, 'user_order.html', {'msg': 'No orders placed yet.'})
    else:
        return HttpResponse("User is not logged in.")
    



import random
import smtplib
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.core.mail import send_mail
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from .models import userDetails

# Global dictionary to store OTPs temporarily
otp_storage = {}

# Safe email validation function (without forcing MX record check)
def is_valid_email(email):
    try:
        validate_email(email)  # Basic format check
        return True
    except ValidationError:
        return False

# Function to generate OTP
def generate_otp():
    return str(random.randint(100000, 999999))

# Function to send OTP
def send_otp(email, otp):
    subject = "Your OTP for Registration"
    message = f"Your OTP for registration is: {otp}. Please do not share it with anyone."
    sender_email = "vaishnavigk.mca23@bmsce.ac.in"
    recipient_email = [email]

    try:
        send_mail(subject, message, sender_email, recipient_email)
        return True
    except smtplib.SMTPException:
        return False

# Registration Function
def reg(req):
    if req.method == "POST":
        username = req.POST.get("username")
        upassword = req.POST.get("password")
        Cpassword = req.POST.get("Cpassword")
        uphoneNumber = req.POST.get("phoneNumber")
        ugender = req.POST.get("gender")
        ucategory = req.POST.get("category")

        # Check if email format is valid
        if not is_valid_email(username):
            return render(req, "reg.html", {"msg": "Invalid email format!"})

        # Check if user already exists
        if userDetails.objects.filter(username=username).exists():
            return render(req, "reg.html", {"msg": "User already exists!"})

        # Check if passwords match
        if upassword != Cpassword:
            return render(req, "reg.html", {"msg": "Passwords do not match!"})

        # Generate OTP
        otp = generate_otp()
        otp_storage[username] = otp  # Store OTP temporarily
        
        # Send OTP to email
        if send_otp(username, otp):
            req.session["temp_user"] = {
                "username": username,
                "password": upassword,
                "Cpassword": Cpassword,
                "phoneNumber": uphoneNumber,
                "gender": ugender,
                "category": ucategory,
            }
            return redirect("/verify-otp/")
        else:
            return render(req, "reg.html", {"msg": "Error sending OTP. Try again!"})

    return render(req, "reg.html")

# OTP Verification Function
def verify_otp(req):
    if req.method == "POST":
        entered_otp = req.POST.get("otp")
        user_data = req.session.get("temp_user", {})
        username = user_data.get("username")

        if username in otp_storage and otp_storage[username] == entered_otp:
            # Save user details after successful OTP verification
            userDetails.objects.create(
                username=user_data["username"],
                password=user_data["password"],
                Cpassword=user_data["Cpassword"],
                phoneNumber=user_data["phoneNumber"],
                gender=user_data["gender"],
                category=user_data["category"],
            )

            del req.session["temp_user"]  # Remove temporary data
            del otp_storage[username]  # Remove OTP from storage

            return HttpResponseRedirect("/reg/login/")
        else:
            return render(req, "verify_otp.html", {"msg": "Invalid OTP. Try again!"})

    return render(req, "verify_otp.html")




import razorpay
from django.conf import settings
from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Payment

# Initialize Razorpay client
razorpay_client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

def payment_page(request):
    return render(request, "payment.html")

def create_order(request):
    if request.method == "POST":
        amount = int(request.POST.get("amount")) * 100  # Razorpay takes amount in paise
        currency = "INR"

        # Create order
        order_data = {
            "amount": amount,
            "currency": currency,
            "payment_capture": "1"
        }
        order = razorpay_client.order.create(order_data)

        # Save order in the database
        payment = Payment.objects.create(order_id=order["id"], amount=amount / 100, status=order["status"])

        return JsonResponse(order)
    
def verify_payment(request):
    if request.method == "POST":
        data = request.POST
        razorpay_payment_id = data.get("razorpay_payment_id")
        razorpay_order_id = data.get("razorpay_order_id")
        razorpay_signature = data.get("razorpay_signature")

        # Verify payment signature
        try:
            razorpay_client.utility.verify_payment_signature(data)

            # Update payment status in DB
            payment = Payment.objects.get(order_id=razorpay_order_id)
            payment.payment_id = razorpay_payment_id
            payment.status = "paid"
            payment.save()

            return JsonResponse({"status": "success"})
        except razorpay.errors.SignatureVerificationError:
            return JsonResponse({"status": "failure"}, status=400)
        
import razorpay
from django.conf import settings
from django.http import JsonResponse
from .models import Payment

razorpay_client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

def create_order(request):
    if request.method == "POST":
        total_price = request.session.get('total_price', 0)  # Get total from session
        amount = int(total_price * 100)  # Convert to paise

        order_data = {
            "amount": amount,
            "currency": "INR",
            "payment_capture": "1"
        }
        order = razorpay_client.order.create(order_data)

        Payment.objects.create(
            order_id=order["id"],
            amount=total_price,  # Store in INR
            status="Created"
        )

        return JsonResponse(order)
from django.http import JsonResponse

def get_cart_total(request):
    """Fetch total cart amount from session and return as JSON."""
    total_price = request.session.get('total_price', 0)  # Default to 0 if not found
    return JsonResponse({"total_amount": total_price})

import random
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.core.mail import send_mail
from django.core.exceptions import ObjectDoesNotExist
from .models import userDetails

# Temporary OTP storage
otp_storage = {}
def forgot_password(request):
    if request.method == "POST":
        email = request.POST.get("email")

        # Check if user exists
        try:
            user = userDetails.objects.get(username=email)
        except ObjectDoesNotExist:
            return render(request, "forgot_password.html", {"msg": "User not found!"})

        # Generate OTP
        otp = str(random.randint(100000, 999999))
        otp_storage[email] = otp  # Store OTP temporarily

        # Send OTP via Email
        subject = "Your OTP for Password Reset"
        message = f"Your OTP for resetting the password is: {otp}. Please do not share it with anyone."
        sender_email = "vaishnavigk.mca23@bmsce.ac.in"
        recipient_email = [email]

        try:
            send_mail(subject, message, sender_email, recipient_email)
            request.session["reset_email"] = email  # Store email in session
            return redirect("verify_reset_otp")
        except:
            return render(request, "forgot_password.html", {"msg": "Error sending OTP. Try again!"})

    return render(request, "forgot_password.html")
def verify_reset_otp(request):
    if request.method == "POST":
        entered_otp = request.POST.get("otp")
        email = request.session.get("reset_email")

        if email in otp_storage and otp_storage[email] == entered_otp:
            del otp_storage[email]  # Remove OTP after verification
            return redirect("reset_password")
        else:
            return render(request, "verify_reset_otp.html", {"msg": "Invalid OTP. Try again!"})

    return render(request, "verify_reset_otp.html")
def reset_password(request):
    if request.method == "POST":
        new_password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")
        email = request.session.get("reset_email")

        if new_password != confirm_password:
            return render(request, "reset_password.html", {"msg": "Passwords do not match!"})

        try:
            user = userDetails.objects.get(username=email)
            user.password = new_password
            user.Cpassword = new_password
            user.save()

            del request.session["reset_email"]  # Clear session data
            return HttpResponseRedirect("/reg/login/")
        except ObjectDoesNotExist:
            return render(request, "reset_password.html", {"msg": "User not found!"})

    return render(request, "reset_password.html")


from django.shortcuts import render
from .models import userinfo, item, Location, userDetails

def display_tables(request):
    # Fetch user purchase details (Table 1 remains unchanged)
    user_data = userinfo.objects.all()

    # Fetch all items along with seller details
    item_details = item.objects.select_related('seller').all()

    # Store item-wise details in a list
    item_list = []
    
    for product in item_details:
        seller = product.seller  # Get seller from item model
        seller_name = seller.username if seller else "Unknown"

        # Fetch seller's location from Location table
        location_obj = Location.objects.filter(user=seller).first()
        location_str = f"{location_obj.house_number}, {location_obj.cross_and_main}, {location_obj.area}, {location_obj.district}, {location_obj.pincode}" if location_obj else "Unknown"

        # Append each item separately
        item_list.append({
            "item_name": product.name,  # ✅ Display all items (Primary Key)
            "seller_name": seller_name,  # ✅ Get seller name
            "location": location_str  # ✅ Get location from Location table
        })

    context = {
        'user_data': user_data,  # ✅ Table 1 remains unchanged
        'items_info': item_list,  # ✅ Table 2 now correctly displays all items
    }

    return render(request, 'tables.html', context)
